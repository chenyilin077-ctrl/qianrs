#include "main.h"
#include "string.h"
#include "main.h"
#include "lcd.h"
#include "touch.h"
#include "usart.h"
#include "cm.h"
#include "pcf8574.h"
extern const unsigned char gImage_23[76800];
char p1[]={0xAA ,0x00, 0x04};
char p2[]={0xAA ,0x00, 0x05};
char p3[]={0xAA ,0x00, 0x06};
char p4[]={0xAA ,0x00, 0x07};
/* 0=������  1=��������  2=SOSҳ */
uint8_t pageFlag = 0;

/* �������� */
void draw_main_page(void)
{
    pageFlag = 0;
    lcd_clear(WHITE);
    /* ����ԭ������������Ԫ���ճ� */
    lcd_show_rgb565(0, 0, 800, 480, (uint16_t*)gImage_23);
    HAL_Delay(100);
    lcd_show_chinese(50,50,0,32,0);
    lcd_show_chinese(100,50,1,32,0);
    lcd_show_chinese(150,50,2,32,0);
    lcd_show_chinese(550,50,3,32,0);
    lcd_show_chinese(600,50,4,32,0);
    lcd_show_chinese(650,50,2,32,0);
    lcd_show_chinese(250,50,1,32,0);
    lcd_show_chinese(750,50,5,32,0);
    lcd_show_string(360, 150, 200, 200, 32, "SOS", RED);
}

/* ������ҳ */
 void draw_help_page(void)
{
    pageFlag = 1;
    lcd_clear(WHITE);
    lcd_draw_rectangle(400, 400, 500, 450, BLACK);
    lcd_show_string(420,410,100,32,32,"BACK",BLACK);
    lcd_show_chinese(150,200,6,32,0);
    lcd_show_chinese(190,200,7,32,0);
    lcd_show_chinese(230,200,8,32,0);
    lcd_show_chinese(270,200,9,32,0);
    lcd_show_chinese(310,200,10,32,0);
    lcd_show_chinese(350,200,11,32,0);
    lcd_show_chinese(390,200,12,32,0);
    lcd_show_chinese(430,200,13,32,0);
    lcd_show_chinese(470,200,14,32,0);
    lcd_show_chinese(510,200,15,32,0);
    lcd_show_chinese(550,200,16,32,0);
    lcd_show_chinese(590,200,17,32,0);
}
/* ������ҳ */
 void draw_help_page1(void)
{
    pageFlag = 1;
    lcd_clear(WHITE);
    lcd_draw_rectangle(400, 400, 500, 450, BLACK);
    lcd_show_string(420,410,100,32,32,"BACK",BLACK);
    lcd_show_chinese(150,200,18,32,0);
    lcd_show_chinese(190,200,19,32,0);
    lcd_show_chinese(230,200,20,32,0);
    lcd_show_chinese(270,200,21,32,0);
    lcd_show_chinese(310,200,22,32,0);
    lcd_show_chinese(350,200,23,32,0);
    lcd_show_chinese(390,200,24,32,0);
    lcd_show_chinese(430,200,25,32,0);
    lcd_show_chinese(470,200,26,32,0);
    lcd_show_chinese(510,200,27,32,0);
    
}

/* ������ҳ */
 void draw_help_page2(void)
{
   pageFlag = 1;
    lcd_clear(WHITE);
    lcd_draw_rectangle(400, 400, 500, 450, BLACK);
    lcd_show_string(420,410,100,32,32,"BACK",BLACK);
    lcd_show_chinese(150,200,18,32,0);
    lcd_show_chinese(190,200,19,32,0);
    lcd_show_chinese(230,200,20,32,0);
    lcd_show_chinese(270,200,21,32,0);
    lcd_show_chinese(310,200,22,32,0);
    lcd_show_chinese(350,200,23,32,0);
    lcd_show_chinese(390,200,24,32,0);
    lcd_show_chinese(430,200,25,32,0);
    lcd_show_chinese(470,200,26,32,0);
    lcd_show_chinese(510,200,28,32,0);
}

/* ������ҳ */
 void draw_help_page3(void)
{
    pageFlag = 1;
    lcd_clear(WHITE);
    lcd_draw_rectangle(400, 400, 500, 450, BLACK);
    lcd_show_string(420,410,100,32,32,"BACK",BLACK);
    lcd_show_chinese(150,200,18,32,0);
    lcd_show_chinese(190,200,19,32,0);
    lcd_show_chinese(230,200,20,32,0);
    lcd_show_chinese(270,200,21,32,0);
    lcd_show_chinese(310,200,22,32,0);
    lcd_show_chinese(350,200,23,32,0);
    lcd_show_chinese(390,200,24,32,0);
    lcd_show_chinese(430,200,25,32,0);
    lcd_show_chinese(470,200,26,32,0);
    lcd_show_chinese(510,200,29,32,0);
}

/* ������ҳ */
 void draw_help_page4(void)
{
 pageFlag = 1;
    lcd_clear(WHITE);
    lcd_draw_rectangle(400, 400, 500, 450, BLACK);
    lcd_show_string(420,410,100,32,32,"BACK",BLACK);
    lcd_show_chinese(150,200,18,32,0);
    lcd_show_chinese(190,200,19,32,0);
    lcd_show_chinese(230,200,20,32,0);
    lcd_show_chinese(270,200,21,32,0);
    lcd_show_chinese(310,200,22,32,0);
    lcd_show_chinese(350,200,23,32,0);
    lcd_show_chinese(390,200,24,32,0);
    lcd_show_chinese(430,200,25,32,0);
    lcd_show_chinese(470,200,26,32,0);
    lcd_show_chinese(510,200,30,32,0);
}

void handle_touch(void)                                                                                                      
{
    tp_dev.scan(0);
    static uint8_t last_down = 0;
    uint8_t now_down = (tp_dev.sta & TP_PRES_DOWN) ? 1 : 0;
    if (now_down && !last_down)
    {
        uint16_t x = tp_dev.x[0];
        uint16_t y = tp_dev.y[0];
        uint32_t t = HAL_GetTick();
        static uint32_t t1,t2,t3,t4,t5;

        if (pageFlag == 0)          /* ---------- ������ ---------- */
        {
            if (x >= 320 && x <= 380 && y >= 350 && y <= 400 && (t - t1 > 200))
            { HAL_UART_Transmit_DMA(&huart5, (uint8_t *)p1, 3); t1 = t; }
            else if (x >= 300 && x <= 350 && y >= 210 && y <= 250 && (t - t2 > 200))
            { HAL_UART_Transmit_DMA(&huart5, (uint8_t *)p2, 3); t2 = t; }
            else if (x >= 550 && x <= 590 && y >= 200 && y <= 240 && (t - t3 > 200))
            { HAL_UART_Transmit_DMA(&huart5, (uint8_t *)p3, 3); t3 = t; }
            else if (x >= 650 && x <= 720 && y >= 270 && y <= 320 && (t - t4 > 200))
            { HAL_UART_Transmit_DMA(&huart5, (uint8_t *)p4, 3); t4 = t; }
            else if (x >= 360 && x <= 450 && y >= 150 && y <= 200 && (t - t5 > 200))
            { draw_help_page(); t5 = t; }      /* �������ҳ */
        }
        else if (pageFlag == 1)     /* ---------- ����ҳ ---------- */
        {
            if (x >= 400 && x <= 500 && y >= 400 && y <= 450 && (t - t5 > 200))
						HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,GPIO_PIN_SET);
            { draw_main_page(); t5 = t; }      /* ���������� */
        }
    }
    last_down = now_down;
 
}
