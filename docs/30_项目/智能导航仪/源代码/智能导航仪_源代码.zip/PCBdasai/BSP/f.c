#include "f.h"
const uint16_t bg[480UL * 272];