/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "X_V2.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE BEGIN PV */
#define K230_CMD_LEN  30  // 确保这个宏在这里

uint8_t k230_rx_buf[K230_CMD_LEN]; 
uint8_t k230_rx_count = 0;         
volatile bool k230_rx_flag = false;  // 【统一名字】全用 k230_rx_flag
/* USER CODE END PV */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
void Gimbal_Init_Zero(void)
{
    // ==================== 0. 核心修正：上电先死等1秒 ====================
    // 刚通电这一秒，手把云台扶正！
    // 这一秒是留给两个电机驱动器自己开机初始化、屏幕亮起的时间
    HAL_Delay(1000); 

    // ==================== 1. 使能 1 号电机 ====================
    X_V2_En_Control(MOTOR_YAW_ID, true, false);
    while(huart1.gState != HAL_UART_STATE_READY);
    HAL_Delay(50); // 拉长软件缓冲，确保数据完全发完
    
    // ==================== 2. 使能 2 号电机 ====================
    X_V2_En_Control(MOTOR_PITCH_ID, true, false);
    while(huart1.gState != HAL_UART_STATE_READY);
    HAL_Delay(100); // 留 100ms 让两台电机的电流彻底稳定、锁死机械
    

    // ==================== 3. 将 1 号位置记忆为绝对零点 ====================
    X_V2_Reset_CurPos_To_Zero(MOTOR_YAW_ID);
    while(huart1.gState != HAL_UART_STATE_READY);
    
    // 【极其关键】1号电机清零后，必须死等 500 毫秒！
    // 因为电机内部写 Flash 记忆零点需要很长时间，此时绝对不能干扰它
    HAL_Delay(500); 


    // ==================== 4. 将 2 号位置记忆为绝对零点 ====================
    X_V2_Reset_CurPos_To_Zero(MOTOR_PITCH_ID);
    while(huart1.gState != HAL_UART_STATE_READY);
    
    // 同样死等 500 毫秒让 2 号电机写完 Flash
    HAL_Delay(500); 
}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  uint32_t last_track_time = 0;
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  //HAL_TIM_Base_Start_IT(&htim5);
  // 在 main.c 的 while(1) 之前调用一次，作为第一次启动
  __HAL_UART_CLEAR_IDLEFLAG(&huart1); 											// 清除IDLE标志
  __HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE); 							// 使能串UART1 IDLE中断
  HAL_UART_Receive_DMA(&huart1, (uint8_t *)rxCmd, CMD_LEN); // 开启DMA接收模

  /* USER CODE BEGIN WHILE */
  Gimbal_Init_Zero();
  __HAL_UART_CLEAR_OREFLAG(&huart2);
	__HAL_UART_FLUSH_DRREGISTER(&huart2);
	HAL_UART_Receive_DMA(&huart2, (uint8_t *)k230_rx_buf, K230_CMD_LEN);
	__HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE);
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		// 只有当接收到 K230 的数据包，且距离上一次控制已经过去了 30 毫秒以上
    if (k230_rx_flag && (HAL_GetTick() - last_track_time >= 30))
    {
        k230_rx_flag = false;       // 清除接收标志
        last_track_time = HAL_GetTick(); // 记录当前系统时间戳
        
        // 调用解析和控制函数
        Parse_K230_Black_Target(k230_rx_buf, k230_rx_count);
			  __HAL_UART_CLEAR_OREFLAG(&huart2); 
        HAL_UART_Receive_DMA(&huart2, (uint8_t *)k230_rx_buf, K230_CMD_LEN);
    }
    
    // 如果 k230_rx_flag 触发了，但 30ms 时间没到，就直接清除掉它，防止旧数据堆积
    if (k230_rx_flag && (HAL_GetTick() - last_track_time < 30))
    {
        k230_rx_flag = false; 
    }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
