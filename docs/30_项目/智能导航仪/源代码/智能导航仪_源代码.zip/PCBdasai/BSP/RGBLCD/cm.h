#ifndef __cm_H
#define __cm_H
void handle_touch(void);
void draw_main_page(void);
void draw_help_page(void);
#endif
