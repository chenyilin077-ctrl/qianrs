#include "X_V2.h"

/**********************************************************
***	X_V2步进闭环控制例程
***	编写作者：ZHANGDATOU
***	技术支持：张大头闭环伺服
***	淘宝店铺：https://zhangdatou.taobao.com
***	CSDN博客：http s://blog.csdn.net/zhangdatou666
***	qq交流群：262438510
**********************************************************/

__IO uint16_t MMCL_count = 0, MMCL_cmd[MMCL_LEN] = {0};

/**********************************************************
*** 触发动作命令
**********************************************************/
/**
  * @brief    触发编码器校准
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
#include "math.h"
#include "stdlib.h"

#define IMG_CENTER_X    320.0f
#define IMG_CENTER_Y    240.0f
#define MOTOR_YAW_ID    0x01
#define MOTOR_PITCH_ID  0x02
// 速度控制常量调机参数
#define SPEED_KP_YAW     0.15f   // 航向轴速度P系数。如果追踪太慢就调大，如果产生高频晃荡就调小
#define SPEED_KP_PITCH   0.15f   // 俯仰轴速度P系数

#define MAX_VEL_YAW      300.0f  // 限制航向轴最高转速（根据你的实际单位微调）
#define MAX_VEL_PITCH    200.0f  // 限制俯仰轴最高转速

#define ACC_YAW          400     // 航向轴响应加速度（值大反应快，值小动作柔和）
#define ACC_PITCH        400     // 俯仰轴响应加速度

void Parse_K230_Black_Target(uint8_t *pBuffer, uint16_t len)
{
    for (uint16_t i = 0; i < len - 6; i++)
    {
        // 严格验证帧头帧尾
        if (pBuffer[i] == 0xAA && pBuffer[i+1] == 0x55 && pBuffer[i+6] == 0xBB)
        {
            int16_t target_x = (pBuffer[i+2] << 8) | pBuffer[i+3];
            int16_t target_y = (pBuffer[i+4] << 8) | pBuffer[i+5];
            
            // 计算图像中心与绿色目标的像素偏差
            float error_x = IMG_CENTER_X - (float)target_x;
            float error_y = IMG_CENTER_Y - (float)target_y;
            
            float vel_yaw = 0.0f;
            float vel_pitch = 0.0f;
            uint8_t dir_yaw = 0;
            uint8_t dir_pitch = 0;

            // ==================== 1. 航向轴（左右）360° 纯直驱 ====================
            if (fabs(error_x) > 10.0f) // 10像素死区
            {
                // 用最原始、没有任何软件干预的逻辑计算速度
                vel_yaw = error_x * SPEED_KP_YAW;
                
                // 仅根据 error_x 的正负来决定 dir_yaw 的物理方向，没有任何历史状态依赖，绝不卡死
                if (vel_yaw >= 0.0f) {
                    dir_yaw = 0; 
                } else {
                    dir_yaw = 1;
                    vel_yaw = -vel_yaw; // 转为正数
                }
                
                if (vel_yaw > MAX_VEL_YAW) vel_yaw = MAX_VEL_YAW;
            }
            else
            {
                vel_yaw = 0.0f;
                dir_yaw = 0;
            }

            // ==================== 2. 俯仰轴（上下）纯直驱 ====================
            if (fabs(error_y) > 10.0f) 
            {
                vel_pitch = error_y * SPEED_KP_PITCH;
                
                if (vel_pitch >= 0.0f) {
                    dir_pitch = 0;
                } else {
                    dir_pitch = 1;
                    vel_pitch = -vel_pitch;
                }
                
                if (vel_pitch > MAX_VEL_PITCH) vel_pitch = MAX_VEL_PITCH;
            }
            else
            {
                vel_pitch = 0.0f;
                dir_pitch = 0;
            }

            // ==================== 串行无冲突物理发射闸门 ====================
            // ⚠️ 重点观察：如果刷入后开始动了，但左右方向是反的，直接把这里的 dir_yaw 改成 (dir_yaw == 0 ? 1 : 0) 或者 !dir_yaw
            X_V2_Vel_Control(MOTOR_YAW_ID, dir_yaw, ACC_YAW, vel_yaw, false);
            while(huart1.gState != HAL_UART_STATE_READY);
            HAL_Delay(5);
            
            X_V2_Vel_Control(MOTOR_PITCH_ID, dir_pitch, ACC_PITCH, vel_pitch, false);
            while(huart1.gState != HAL_UART_STATE_READY);
            HAL_Delay(5);

            break;
        }
    }
}
void X_V2_Trig_Encoder_Cal(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x06;                       // 功能码
  cmd[2] =  0x45;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
	HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    重启电机（X42S/Y42）
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Reset_Motor(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x08;                       // 功能码
  cmd[2] =  0x97;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
	HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    将当前位置清零
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Reset_CurPos_To_Zero(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x0A;                       // 功能码
  cmd[2] =  0x6D;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
	HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    解除堵转保护
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Reset_Clog_Pro(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x0E;                       // 功能码
  cmd[2] =  0x52;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    恢复出厂设置
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Restore_Motor(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x0F;                       // 功能码
  cmd[2] =  0x5F;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
	HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**********************************************************
*** 运动控制命令
**********************************************************/
/**
  * @brief    多电机命令（X42S/Y42）
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Multi_Motor_Cmd(uint8_t addr)
{
  uint16_t i = 0, j = 0, len = 0; __IO static uint8_t cmd[MMCL_LEN] = {0};

	// 多电机命令长度大于0
	if(MMCL_count > 0)
	{
		// 多电机命令的总字节数
		len = MMCL_count + 5;

		// 装载命令
		cmd[0] = addr;                       // 地址
		cmd[1] = 0xAA;                       // 功能码
		cmd[2] = (uint8_t)(len >> 8);				 // 总字节数高8位
		cmd[3] = (uint8_t)(len); 		 				 // 总字节数低8位
		for(i=0,j=4; i < MMCL_count; i++,j++) { cmd[j] = MMCL_cmd[i]; }
		cmd[j] = 0x6B; ++j;                  // 校验字节

		// 发送命令
		HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, j); MMCL_count = 0;
	}
	else
	{
		MMCL_count = 0;
	}
}

/**
  * @brief    使能信号控制
  * @param    addr  ：电机地址
  * @param    state ：使能状态     ，true为使能电机，false为关闭电机
  * @param    snF   ：多机同步标志 ，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_En_Control(uint8_t addr, bool state, bool snF)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xF3;                       // 功能码
  cmd[2] =  0xAB;                       // 辅助码
  cmd[3] =  (uint8_t)state;             // 使能状态
  cmd[4] =  snF;                        // 多机同步运动标志
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    力矩模式
  * @param    addr  	：电机地址
  * @param    sign  	：符号（方向）		，0为正，1为负
  * @param    t_ramp	：电流斜率(Ma/s)	，范围0 - 65535Ma/s
  * @param    torque	：力矩电流(Ma)		，范围0 - 6000Ma
  * @param    snF   	：多机同步标志		，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Torque_Control(uint8_t addr, uint8_t sign, uint16_t t_ramp, uint16_t torque, bool snF)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xF5;                       // 功能码
  cmd[2] =  sign;                       // 符号（方向）
  cmd[3] =  (uint8_t)(t_ramp >> 8);     // 电流斜率(Ma/s)
  cmd[4] =  (uint8_t)(t_ramp >> 0);
  cmd[5] =  (uint8_t)(torque >> 8);     // 力矩电流(Ma)
  cmd[6] =  (uint8_t)(torque >> 0);
  cmd[7] =  snF;                        // 多机同步标志
  cmd[8] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 9);
}

/**
  * @brief    力矩模式限速控制（X42S/Y42）
  * @param    addr  	：电机地址
  * @param    sign  	：符号（方向）		，0为正，1为负
  * @param    t_ramp	：电流斜率(Ma/s)	，范围0 - 65535Ma/s
  * @param    torque	：力矩电流(Ma)		，范围0 - 6000Ma
  * @param    snF   	：多机同步标志		，false为不启用，true为启用
	* @param    maxVel	：最大速度(RPM)	，范围0.0 - 3000.0RPM
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Torque_LV_Control(uint8_t addr, uint8_t sign, uint16_t t_ramp, uint16_t torque, bool snF, float maxVel)
{
  __IO static uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(maxVel * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xC5;                      // 功能码
  cmd[2]  =  sign;                      // 符号（方向）
  cmd[3]  =  (uint8_t)(t_ramp >> 8);    // 电流斜率(Ma/s)
  cmd[4]  =  (uint8_t)(t_ramp >> 0);
  cmd[5]  =  (uint8_t)(torque >> 8);    // 力矩电流(Ma)
  cmd[6]  =  (uint8_t)(torque >> 0);
  cmd[7]  =  snF;                       // 多机同步标志
  cmd[8]  =  (uint8_t)(v >> 8);    			// 最大速度(RPM)
  cmd[9]  =  (uint8_t)(v >> 0);
  cmd[10] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 11);
}

/**
  * @brief    速度模式
  * @param    addr  ：电机地址
  * @param    dir   ：方向						，0为CW，1为CCW
  * @param    acc   ：加速度(RPM/s)	，范围0 - 65535RPM/s
  * @param    vel		：速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    snF   ：多机同步标志		，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Vel_Control(uint8_t addr, uint8_t dir, uint16_t acc, float vel, bool snF)
{
  __IO static uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f);

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xF6;                       // 功能码
  cmd[2] =  dir;                        // 符号（方向）
  cmd[3] =  (uint8_t)(acc >> 8);     		// 加速度(RPM/s)
  cmd[4] =  (uint8_t)(acc >> 0);
  cmd[5] =  (uint8_t)(v >> 8);        	// 速度(RPM)
  cmd[6] =  (uint8_t)(v >> 0);
  cmd[7] =  snF;                        // 多机同步运动标志
  cmd[8] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 9);
}

/**
  * @brief    速度模式限电流控制（X42S/Y42）
  * @param    addr  ：电机地址
  * @param    dir   ：方向						，0为CW，1为CCW
  * @param    acc   ：加速度(RPM/s)	，范围0 - 65535RPM/s
  * @param    vel		：速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    snF   ：多机同步标志		，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)		，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Vel_LC_Control(uint8_t addr, uint8_t dir, uint16_t acc, float vel, bool snF, uint16_t maxCur)
{
  __IO static uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xC6;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(acc >> 8);     	// 加速度(RPM/s)
  cmd[4]  =  (uint8_t)(acc >> 0);
  cmd[5]  =  (uint8_t)(v >> 8);        	// 速度(RPM)
  cmd[6]  =  (uint8_t)(v >> 0);
  cmd[7]  =  snF;                       // 多机同步运动标志
	cmd[8]  =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[9]  =  (uint8_t)(maxCur >> 0);
  cmd[10] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 11);
}

/**
  * @brief    直通限速位置模式
  * @param    addr	：电机地址
  * @param    dir   ：方向								，0为CW，1为CCW
  * @param    vel		：运动速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置角度(°)				，范围0.0°- (2^32 - 1) / 10°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Bypass_Pos_LV_Control(uint8_t addr, uint8_t dir, float vel, float pos, uint8_t raf, bool snF)
{
  uint8_t cmd[16] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xFB;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(v >> 8);       	// 运动速度(RPM)
  cmd[4]  =  (uint8_t)(v >> 0);
  cmd[5]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[6]  =  (uint8_t)(p >> 16);
  cmd[7]  =  (uint8_t)(p >> 8);
  cmd[8]  =  (uint8_t)(p >> 0);
  cmd[9]  =  raf;                       // 相位/绝对运动标志
  cmd[10] =  snF;                       // 多机同步运动标志
  cmd[11] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 12);
}

/**
  * @brief    直通限速位置模式限电流控制
  * @param    addr	：电机地址
  * @param    dir   ：方向								，0为CW，1为CCW
  * @param    vel		：运动速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置角度(°)				，范围0.0°- (2^32 - 1) / 10°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)		，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Bypass_Pos_LV_LC_Control(uint8_t addr, uint8_t dir, float vel, float pos, uint8_t raf, bool snF, uint16_t maxCur)
{
  uint8_t cmd[16] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xCB;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(v >> 8);       	// 运动速度(RPM)
  cmd[4]  =  (uint8_t)(v >> 0);
  cmd[5]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[6]  =  (uint8_t)(p >> 16);
  cmd[7]  =  (uint8_t)(p >> 8);
  cmd[8]  =  (uint8_t)(p >> 0);
  cmd[9]  =  raf;                       // 相位/绝对运动标志
  cmd[10] =  snF;                       // 多机同步运动标志
	cmd[11] =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[12] =  (uint8_t)(maxCur >> 0);
  cmd[13] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 14);
}

/**
  * @brief    梯形曲线加减速位置模式控制
  * @param    addr  ：电机地址
  * @param    dir   ：方向								，0为CW，其余值为CCW
  * @param    acc   ：加速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    dec   ：减速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    vel		：最大速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置(°)						，范围0.0°- (2^32 - 1)°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志					，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Traj_Pos_Control(uint8_t addr, uint8_t dir, uint16_t acc, uint16_t dec, float vel, float pos, uint8_t raf, bool snF)
{
  uint8_t cmd[32] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xFD;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(acc >> 8);       // 加速加速度(RPM/s)
  cmd[4]  =  (uint8_t)(acc >> 0);
  cmd[5]  =  (uint8_t)(dec >> 8);       // 减速加速度(RPM/s)
  cmd[6]  =  (uint8_t)(dec >> 0);
  cmd[7]  =  (uint8_t)(v >> 8);       	// 最大速度(RPM)
  cmd[8]  =  (uint8_t)(v >> 0);
  cmd[9]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[10] =  (uint8_t)(p >> 16);
  cmd[11] =  (uint8_t)(p >> 8);
  cmd[12] =  (uint8_t)(p >> 0);
  cmd[13] =  raf;                       // 相位/绝对运动标志
  cmd[14] =  snF;                       // 多机同步运动标志
  cmd[15] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 16);
}

/**
  * @brief    梯形曲线加减速位置模式限电流控制（X42S/Y42）
  * @param    addr  ：电机地址
  * @param    dir   ：方向								，0为CW，其余值为CCW
  * @param    acc   ：加速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    dec   ：减速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    vel		：最大速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置(°)						，范围0.0°- (2^32 - 1)°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)				，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Traj_Pos_LC_Control(uint8_t addr, uint8_t dir, uint16_t acc, uint16_t dec, float vel, float pos, uint8_t raf, bool snF, uint16_t maxCur)
{
  uint8_t cmd[32] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xCD;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(acc >> 8);       // 加速加速度(RPM/s)
  cmd[4]  =  (uint8_t)(acc >> 0);
  cmd[5]  =  (uint8_t)(dec >> 8);       // 减速加速度(RPM/s)
  cmd[6]  =  (uint8_t)(dec >> 0);
  cmd[7]  =  (uint8_t)(v >> 8);       	// 最大速度(RPM)
  cmd[8]  =  (uint8_t)(v >> 0);
  cmd[9]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[10] =  (uint8_t)(p >> 16);
  cmd[11] =  (uint8_t)(p >> 8);
  cmd[12] =  (uint8_t)(p >> 0);
  cmd[13] =  raf;                       // 相位/绝对运动标志
  cmd[14] =  snF;                       // 多机同步运动标志
	cmd[15] =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[16] =  (uint8_t)(maxCur >> 0);
  cmd[17] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 18);
}

/**
  * @brief    设置快速梯形曲线位置模式的运动参数（X42S/Y42）
  * @param    addr  ：电机地址
  * @param    acc   ：加速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    dec   ：减速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    vel		：最大速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对电机当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)				，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Set_QTrajPos_Params(uint8_t addr, uint16_t acc, uint16_t dec, float vel, uint8_t raf, bool snF, uint16_t maxCur)
{
  uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xF1;                      // 功能码
  cmd[2]  =  (uint8_t)(acc >> 8);       // 加速加速度(RPM/s)
  cmd[3]  =  (uint8_t)(acc >> 0);
  cmd[4]  =  (uint8_t)(dec >> 8);       // 减速加速度(RPM/s)
  cmd[5]  =  (uint8_t)(dec >> 0);
  cmd[6]  =  (uint8_t)(v >> 8);       	// 最大速度(RPM)
  cmd[7]  =  (uint8_t)(v >> 0);
  cmd[8]  =  raf;                       // 相位/绝对运动标志
  cmd[9]  =  snF;                       // 多机同步运动标志
	cmd[10] =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[11] =  (uint8_t)(maxCur >> 0);
  cmd[12] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 13);
}

/**
  * @brief    快速梯形曲线位置模式控制（X42S/Y42）
  * @param    addr  ：电机地址
  * @param    pos		：位置角度(带符号)，单位：0.1°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_QTrajPos_LC_Control(uint8_t addr, float pos)
{
  uint8_t cmd[16] = {0}; int32_t p = 0;

  // 将位置放大10倍发送过去（保留一位小数）
  p = (int32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xFC;                      // 功能码
  cmd[2]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[3] =  (uint8_t)(p >> 16);
  cmd[4] =  (uint8_t)(p >> 8);
  cmd[5] =  (uint8_t)(p >> 0);
  cmd[6] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 7);
}

/**
  * @brief    立即停止
  * @param    addr  ：电机地址
  * @param    snF   ：多机同步标志，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Stop_Now(uint8_t addr, bool snF)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xFE;                       // 功能码
  cmd[2] =  0x98;                       // 辅助码
  cmd[3] =  snF;                        // 多机同步运动标志
  cmd[4] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 5);
}

/**
  * @brief    多机同步运动
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Synchronous_motion(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xFF;                       // 功能码
  cmd[2] =  0x66;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**********************************************************
*** 原点回零命令
**********************************************************/
/**
  * @brief    设置单圈回零的零点位置
  * @param    addr  ：电机地址
  * @param    svF   ：是否存储标志，false为不存储，true为存储
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Set_O(uint8_t addr, bool svF)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x93;                       // 功能码
  cmd[2] =  0x88;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 5);
}

/**
  * @brief    触发回零
  * @param    addr   ：电机地址
  * @param    o_mode ：回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  * @param    snF   ：多机同步标志，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Trigger_Return(uint8_t addr, uint8_t o_mode, bool snF)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x9A;                       // 功能码
  cmd[2] =  o_mode;                     // 回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  cmd[3] =  snF;                        // 多机同步运动标志，false为不启用，true为启用
  cmd[4] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 5);
}

/**
  * @brief    强制中断并退出回零
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Interrupt(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x9C;                       // 功能码
  cmd[2] =  0x48;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    读取回零参数
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Read_Params(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x22;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改回零参数
  * @param    addr  ：电机地址
  * @param    svF   ：是否存储标志，false为不存储，true为存储
  * @param    o_mode ：回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  * @param    o_dir  ：回零方向，0为CW，其余值为CCW
  * @param    o_vel  ：回零速度，单位：RPM（转/分钟）
  * @param    o_tm   ：回零超时时间，单位：毫秒
  * @param    sl_vel ：无限位碰撞回零检测转速，单位：RPM（转/分钟）
  * @param    sl_ma  ：无限位碰撞回零检测电流，单位：Ma（毫安）
  * @param    sl_ms  ：无限位碰撞回零检测时间，单位：Ms（毫秒）
  * @param    potF   ：上电自动触发回零，false为不使能，true为使能
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Modify_Params(uint8_t addr, bool svF, uint8_t o_mode, uint8_t o_dir, uint16_t o_vel, uint32_t o_tm, uint16_t sl_vel, uint16_t sl_ma, uint16_t sl_ms, bool potF)
{
  __IO static uint8_t cmd[32] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x4C;                       // 功能码
  cmd[2] =  0xAE;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  o_mode;                     // 回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  cmd[5] =  o_dir;                      // 回零方向
  cmd[6]  =  (uint8_t)(o_vel >> 8);     // 回零速度(RPM)高8位字节
  cmd[7]  =  (uint8_t)(o_vel >> 0);     // 回零速度(RPM)低8位字节
  cmd[8]  =  (uint8_t)(o_tm >> 24);     // 回零超时时间(bit24 - bit31)
  cmd[9]  =  (uint8_t)(o_tm >> 16);     // 回零超时时间(bit16 - bit23)
  cmd[10] =  (uint8_t)(o_tm >> 8);      // 回零超时时间(bit8  - bit15)
  cmd[11] =  (uint8_t)(o_tm >> 0);      // 回零超时时间(bit0  - bit7 )
  cmd[12] =  (uint8_t)(sl_vel >> 8);    // 无限位碰撞回零检测转速(RPM)高8位字节
  cmd[13] =  (uint8_t)(sl_vel >> 0);    // 无限位碰撞回零检测转速(RPM)低8位字节
  cmd[14] =  (uint8_t)(sl_ma >> 8);     // 无限位碰撞回零检测电流(Ma)高8位字节
  cmd[15] =  (uint8_t)(sl_ma >> 0);     // 无限位碰撞回零检测电流(Ma)低8位字节
  cmd[16] =  (uint8_t)(sl_ms >> 8);     // 无限位碰撞回零检测时间(Ms)高8位字节
  cmd[17] =  (uint8_t)(sl_ms >> 0);     // 无限位碰撞回零检测时间(Ms)低8位字节
  cmd[18] =  potF;                      // 上电自动触发回零，false为不使能，true为使能
  cmd[19] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 20);
}

/**
  * @brief    读取碰撞回零返回角度（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Read_SL_RP(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x3F;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改碰撞回零返回角度（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    sl_rp 	 ：碰撞回零返回角度，单位0.1°，即给40，就是4.0°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Origin_Modify_SL_RP(uint8_t addr, bool svF, uint16_t sl_rp)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x5C;                      // 功能码
  cmd[2]  =  0xAC;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(sl_rp >> 8);			// 碰撞回零返回角度，单位0.1°
	cmd[5]  =  (uint8_t)(sl_rp >> 0);
  cmd[6]  =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 7);
}

/**********************************************************
*** 读取系统参数命令
**********************************************************/
/**
  * @brief    定时返回信息命令（X42S/Y42）
  * @param    addr  	：电机地址
  * @param    s     	：系统参数类型
	* @param    time_ms ：定时时间
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Auto_Return_Sys_Params_Timed(uint8_t addr, SysParams_t s, uint16_t time_ms)
{
  uint8_t i = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[i] = addr; ++i;                   // 地址

  cmd[i] = 0x11; ++i;                   // 功能码

  cmd[i] = 0x18; ++i;                   // 辅助码

  switch(s)                             // 信息功能码
  {
    case S_VBUS : cmd[i] = 0x24; ++i; break;	// 读取总线电压
		case S_CBUS : cmd[i] = 0x26; ++i; break;	// 读取总线电流
    case S_CPHA : cmd[i] = 0x27; ++i; break;	// 读取相电流
		case S_ENCO : cmd[i] = 0x29; ++i; break;	// 读取编码器原始值
		case S_CLKC : cmd[i] = 0x30; ++i; break;	// 读取实时脉冲数
    case S_ENCL : cmd[i] = 0x31; ++i; break;	// 读取经过线性化校准后的编码器值
		case S_CLKI : cmd[i] = 0x32; ++i; break;	// 读取输入脉冲数
    case S_TPOS : cmd[i] = 0x33; ++i; break;	// 读取电机目标位置
    case S_SPOS : cmd[i] = 0x34; ++i; break;	// 读取电机实时设定的目标位置
		case S_VEL  : cmd[i] = 0x35; ++i; break;	// 读取电机实时转速
    case S_CPOS : cmd[i] = 0x36; ++i; break;	// 读取电机实时位置
    case S_PERR : cmd[i] = 0x37; ++i; break;	// 读取电机位置误差
		case S_VBAT : cmd[i] = 0x38; ++i; break;	// 读取多圈编码器电池电压（Y42）
		case S_TEMP : cmd[i] = 0x39; ++i; break;	// 读取电机实时温度（X42S/Y42）
    case S_FLAG : cmd[i] = 0x3A; ++i; break;	// 读取电机状态标志位
    case S_OFLAG: cmd[i] = 0x3B; ++i; break;	// 读取回零状态标志位
		case S_OAF  : cmd[i] = 0x3C; ++i; break;	// 读取电机状态标志位 + 回零状态标志位（X42S/Y42）
		case S_PIN  : cmd[i] = 0x3D; ++i; break;	// 读取引脚IO状态（X42S/Y42）
    default: break;
  }

	cmd[i] = (uint8_t)(time_ms >> 8);  ++i;	// 定时时间
	cmd[i] = (uint8_t)(time_ms >> 0);  ++i;

  cmd[i] = 0x6B; ++i;                   	// 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, i);
}

/**
  * @brief    读取系统参数
  * @param    addr  ：电机地址
  * @param    s     ：系统参数类型
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Sys_Params(uint8_t addr, SysParams_t s)
{
  uint8_t i = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[i] = addr; ++i;                   // 地址

  switch(s)                             // 功能码
  {
    case S_VBUS : cmd[i] = 0x24; ++i; break;	// 读取总线电压
		case S_CBUS : cmd[i] = 0x26; ++i; break;	// 读取总线电流
    case S_CPHA : cmd[i] = 0x27; ++i; break;	// 读取相电流
		case S_ENCO : cmd[i] = 0x29; ++i; break;	// 读取编码器原始值
		case S_CLKC : cmd[i] = 0x30; ++i; break;	// 读取实时脉冲数
    case S_ENCL : cmd[i] = 0x31; ++i; break;	// 读取经过线性化校准后的编码器值
		case S_CLKI : cmd[i] = 0x32; ++i; break;	// 读取输入脉冲数
    case S_TPOS : cmd[i] = 0x33; ++i; break;	// 读取电机目标位置
    case S_SPOS : cmd[i] = 0x34; ++i; break;	// 读取电机实时设定的目标位置
		case S_VEL  : cmd[i] = 0x35; ++i; break;	// 读取电机实时转速
    case S_CPOS : cmd[i] = 0x36; ++i; break;	// 读取电机实时位置
    case S_PERR : cmd[i] = 0x37; ++i; break;	// 读取电机位置误差
		case S_VBAT : cmd[i] = 0x38; ++i; break;	// 读取多圈编码器电池电压（Y42）
		case S_TEMP : cmd[i] = 0x39; ++i; break;	// 读取电机实时温度（X42S/Y42）
    case S_FLAG : cmd[i] = 0x3A; ++i; break;	// 读取电机状态标志位
    case S_OFLAG: cmd[i] = 0x3B; ++i; break;	// 读取回零状态标志位
		case S_OAF  : cmd[i] = 0x3C; ++i; break;	// 读取电机状态标志位 + 回零状态标志位（X42S/Y42）
		case S_PIN  : cmd[i] = 0x3D; ++i; break;	// 读取引脚状态（X42S/Y42）
		case S_SYS  : cmd[i] = 0x43; ++i; cmd[i] = 0x7A; ++i; break;	// 读取系统状态参数
    default: break;
  }

  cmd[i] = 0x6B; ++i;                   // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, i);
}

/**********************************************************
*** 读写驱动参数命令
**********************************************************/
/**
  * @brief    修改电机ID地址
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    id			 ：默认电机ID为1，可修改为1-255，0为广播地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Motor_ID(uint8_t addr, bool svF, uint8_t id)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xAE;                       // 功能码
  cmd[2] =  0x4B;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  id;                  				// 默认电机ID为1，可修改为1-255，0为广播地址
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改细分值
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    mstep		 ：默认细分为16，可修改为1-2556，0为256细分
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_MicroStep(uint8_t addr, bool svF, uint8_t mstep)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x84;                       // 功能码
  cmd[2] =  0x8A;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  mstep;                 	 		// 默认细分为16，可修改为1-2556，0为256细分
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改掉电标志
  * @param    addr     ：电机地址
  * @param    pdf		 	 ：掉电标志
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_PDFlag(uint8_t addr, bool pdf)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x50;                       // 功能码
  cmd[2] =  pdf;                 	 			// 掉电标志
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    读取选项参数状态（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Opt_Param_Sta(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x1A;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改电机类型（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    mottype	 ：电机类型，默认为0，0表示1.8°步进电机，1表示0.9°步进电机
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Motor_Type(uint8_t addr, bool svF, bool mottype)
{
  __IO static uint8_t cmd[16] = {0}; uint8_t MotType = 0;

	if(mottype) { MotType = 25; } else { MotType = 50; }

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD7;                       // 功能码
  cmd[2] =  0x35;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  MotType;                 	 	// 电机类型，0表示0.9°步进电机，1表示1.8°步进电机
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改固件类型（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    fwtype	 ：固件类型，默认为0，0为X固件，1为Emm固件
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Firmware_Type(uint8_t addr, bool svF, bool fwtype)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD5;                       // 功能码
  cmd[2] =  0x69;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  fwtype;                 	 	// 电机类型，25表示0.9°步进电机，50表示1.8°步进电机
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改开环/闭环控制模式（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    ctrl_mode：控制模式，默认为1,0为开环模式，1为闭环FOC模式
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Ctrl_Mode(uint8_t addr, bool svF, bool ctrl_mode)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x46;                       // 功能码
  cmd[2] =  0x69;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  ctrl_mode;                  // 控制模式，默认为1,0为开环模式，1为闭环FOC模式
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改电机运动正方向（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    dir			 ：电机运动正方向，默认为CW，0为CW（顺时针方向），1为CCW
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Motor_Dir(uint8_t addr, bool svF, bool dir)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD4;                       // 功能码
  cmd[2] =  0x60;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  dir;                  			// 电机运动正方向，默认为CW，0为CW（顺时针方向），1为CCW
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改锁定按键功能（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    lock		 ：锁定按键功能，默认为Disable，0为Disable，1为Enable
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Lock_Btn(uint8_t addr, bool svF, bool lock)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD0;                       // 功能码
  cmd[2] =  0xB3;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  lock;                  			// 锁定按键功能，默认为Disable，0为Disable），1为Enable
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改命令位置角度是否继续缩小10倍输入（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    s_vel		 ：命令位置角度是否继续缩小10倍输入，默认为Disable，0为Disable，1为Enable
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_S_Vel(uint8_t addr, bool svF, bool s_vel)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x4F;                       // 功能码
  cmd[2] =  0x71;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  s_vel;                  		// 命令位置角度是否继续缩小10倍输入，默认为Disable，0为Disable，1为Enable
  cmd[5] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 6);
}

/**
  * @brief    修改开环模式工作电流
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    om_ma 	 ：开环模式工作电流，单位mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_OM_mA(uint8_t addr, bool svF, uint16_t om_ma)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x44;                       // 功能码
  cmd[2] =  0x33;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  (uint8_t)(om_ma >> 8);			// 开环模式工作电流，单位mA
	cmd[5] =  (uint8_t)(om_ma >> 0);
  cmd[6] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 7);
}

/**
  * @brief    修改闭环模式最大电流
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    foc_mA 	 ：闭环模式最大电流，单位mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_FOC_mA(uint8_t addr, bool svF, uint16_t foc_mA)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x45;                       // 功能码
  cmd[2] =  0x66;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  (uint8_t)(foc_mA >> 8);			// 闭环模式最大电流，单位mA
	cmd[5] =  (uint8_t)(foc_mA >> 0);
  cmd[6] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 7);
}

/**
  * @brief    读取PID参数
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_PID_Params(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x21;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改PID参数
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    pTkp 	 	 ：梯形曲线位置环比例系数，默认为126640
	* @param    pBkp 	 	 ：直通限速位置环比例系数，默认为126640
	* @param    vkp 	 	 ：速度环比例系数，42默认为15600
	* @param    vki 	 	 ：速度环积分系数，42默认为26
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_PID_Params(uint8_t addr, bool svF, uint32_t pTkp, uint32_t pBkp, uint32_t vkp, uint32_t vki)
{
  __IO static uint8_t cmd[32] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x4A;                      // 功能码
  cmd[2]  =  0xC3;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(pTkp >> 24);			// pTkp
	cmd[5]  =  (uint8_t)(pTkp >> 16);
	cmd[6]  =  (uint8_t)(pTkp >> 8);
	cmd[7]  =  (uint8_t)(pTkp >> 0);
	cmd[8]  =  (uint8_t)(pBkp >> 24);			// pBkp
	cmd[9]  =  (uint8_t)(pBkp >> 16);
	cmd[10] =  (uint8_t)(pBkp >> 8);
	cmd[11] =  (uint8_t)(pBkp >> 0);
	cmd[12] =  (uint8_t)(vkp >> 24);			// vkp
	cmd[13] =  (uint8_t)(vkp >> 16);
	cmd[14] =  (uint8_t)(vkp >> 8);
	cmd[15] =  (uint8_t)(vkp >> 0);
	cmd[16] =  (uint8_t)(vki >> 24);			// vki
	cmd[17] =  (uint8_t)(vki >> 16);
	cmd[18] =  (uint8_t)(vki >> 8);
	cmd[19] =  (uint8_t)(vki >> 0);
  cmd[20] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 21);
}

/**
  * @brief    读取DMX512协议参数（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_DMX512_Params(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x49;                       // 功能码
	cmd[2] =  0x78;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    读取DMX512协议参数（X42S/Y42）
  * @param    addr  		：电机地址
  * @param    svF   		：是否存储标志，false为不存储，true为存储
  * @param    tch				：总通道数，默认为192，该值要与自身 DMX512 控制器的总通道数一样
	* @param    nch				：每个电机占用的通道数，默认为1，1为单通道模式,2为双通道模式
	* @param    mode			：运动模式，默认为1，0表示相对位置模式运动，1表示绝对坐标式位置运动
	* @param    vel				：单通道模式的运动速度，默认值为1000， 单位RPM， 即1000RPM；
	* @param    acc				：加速度，acc=加速数值/8=125，加速时间见说明书“5.3.12 位置模式控制（Emm）”
	* @param    vel_step	：双通道模式速度步长，默认值为 10， 即电机运动速度为(通道值 * 10)RPM
	* @param    pos_step	：双通道模式运动步长，默认值为 100， 即电机转动角度为(通道值 * 10.0)°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_DMX512_Params(uint8_t addr, bool svF, uint16_t tch, uint8_t nch, uint8_t mode, uint16_t vel, uint16_t acc, uint16_t vel_step, uint32_t pos_step)
{
  __IO static uint8_t cmd[32] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xD9;                      // 功能码
  cmd[2]  =  0x90;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(tch >> 8);     	// 总通道数
  cmd[5]  =  (uint8_t)(tch >> 0);
	cmd[6]  =  nch;                       // 每个电机占用的通道数
	cmd[7]  =  mode;                      // 运动模式
	cmd[8]  =  (uint8_t)(vel >> 8);     	// 单通道模式的运动速度
  cmd[9]  =  (uint8_t)(vel >> 0);
	cmd[10] =  (uint8_t)(acc >> 8);     	// 双通道模式速度步长
  cmd[11] =  (uint8_t)(acc >> 0);
	cmd[12] =  (uint8_t)(vel_step >> 8);  // 双通道模式速度步长
  cmd[13] =  (uint8_t)(vel_step >> 0);
  cmd[14]  = (uint8_t)(pos_step >> 24);	// 双通道模式运动步长
  cmd[15]  = (uint8_t)(pos_step >> 16);
  cmd[16] =  (uint8_t)(pos_step >> 8);
  cmd[17] =  (uint8_t)(pos_step >> 0);
  cmd[18] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 19);
}

/**
  * @brief    读取位置到达窗口（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Pos_Window(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x41;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改位置到达窗口（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    prw 	 	 ：位置到达窗口，默认值为8，即0.8°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Pos_Window(uint8_t addr, bool svF, uint16_t prw)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD1;                       // 功能码
  cmd[2] =  0x07;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  (uint8_t)(prw >> 8);				// 位置到达窗口，默认值为8，即0.8°
	cmd[5] =  (uint8_t)(prw >> 0);
  cmd[6] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 7);
}

/**
  * @brief    读取过热过流保护检测阈值（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Otocp(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x13;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改过热过流保护检测阈值（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    otp 	 	 ：过热保护检测阈值，默认100℃
	* @param    ocp 	 	 ：过流保护检测阈值，默认6600mA
	* @param    time_ms  ：过热过流检测时间，默认1000ms
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Otocp(uint8_t addr, bool svF, uint16_t otp, uint16_t ocp, uint16_t time_ms)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xD3;                      // 功能码
  cmd[2]  =  0x56;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(otp >> 8);				// 过热保护检测阈值
	cmd[5]  =  (uint8_t)(otp >> 0);
	cmd[6]  =  (uint8_t)(ocp >> 8);				// 过流保护检测阈值
	cmd[7]  =  (uint8_t)(ocp >> 0);
	cmd[8]  =  (uint8_t)(time_ms >> 8);		// 过热过流检测时间
	cmd[9]  =  (uint8_t)(time_ms >> 0);
  cmd[10] =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 11);
}

/**
  * @brief    读取心跳保护功能时间（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Heart_Protect(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x16;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改心跳保护功能时间（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    hp 	 	 	 ：心跳保护时间，单位：ms
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Heart_Protect(uint8_t addr, bool svF, uint32_t hp)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x68;                      // 功能码
  cmd[2]  =  0x38;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(hp >> 24);				// 心跳保护时间，单位：ms
	cmd[5]  =  (uint8_t)(hp >> 16);
	cmd[6]  =  (uint8_t)(hp >> 8);
	cmd[7]  =  (uint8_t)(hp >> 0);
  cmd[8]  =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 9);
}

/**
  * @brief    读取积分限幅/刚性系数（X42S/Y42）
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Integral_Limit(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x23;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 3);
}

/**
  * @brief    修改积分限幅/刚性系数（X42S/Y42）
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    il 	 	 	 ：刚性系数，X 固件默认为X42S/Y42/388、X57S/Y57/512
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Modify_Integral_Limit(uint8_t addr, bool svF, uint32_t il)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x4B;                      // 功能码
  cmd[2]  =  0x57;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(il >> 24);				// 刚性系数，X 固件默认为X42S/Y42/388、X57S/Y57/512
	cmd[5]  =  (uint8_t)(il >> 16);
	cmd[6]  =  (uint8_t)(il >> 8);
	cmd[7]  =  (uint8_t)(il >> 0);
  cmd[8]  =  0x6B;                      // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 9);
}

/**********************************************************
*** 读取所有驱动参数命令
**********************************************************/
/**
  * @brief    读取系统状态参数
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_System_State_Params(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x43;                       // 功能码
	cmd[2] =  0x7A;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}

/**
  * @brief    读取驱动配置参数
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_Read_Motor_Conf_Params(uint8_t addr)
{
  __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x42;                       // 功能码
	cmd[2] =  0x6C;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 发送命令
  HAL_UART_Transmit_DMA(&huart1, (uint8_t *)cmd, 4);
}



/**
***********************************************************
***********************************************************
***
***
*** @brief	以下是把相应命令加载到X42S/Y42多电机命令上的函数（X42S/Y42）
***
***
***********************************************************
***********************************************************
***/
/**********************************************************
*** 触发动作命令
**********************************************************/
/**
  * @brief    触发编码器校准 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Trig_Encoder_Cal(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x06;                       // 功能码
  cmd[2] =  0x45;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    重启电机（X42S/Y42） - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Reset_Motor(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x08;                       // 功能码
  cmd[2] =  0x97;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    将当前位置清零 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Reset_CurPos_To_Zero(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x0A;                       // 功能码
  cmd[2] =  0x6D;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    解除堵转保护 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Reset_Clog_Pro(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x0E;                       // 功能码
  cmd[2] =  0x52;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    恢复出厂设置 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Restore_Motor(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x0F;                       // 功能码
  cmd[2] =  0x5F;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**********************************************************
*** 运动控制命令
**********************************************************/
/**
  * @brief    使能信号控制 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    state ：使能状态     ，true为使能电机，false为关闭电机
  * @param    snF   ：多机同步标志 ，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_En_Control(uint8_t addr, bool state, bool snF)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xF3;                       // 功能码
  cmd[2] =  0xAB;                       // 辅助码
  cmd[3] =  (uint8_t)state;             // 使能状态
  cmd[4] =  snF;                        // 多机同步运动标志
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    力矩模式 - 加载到多电机指令上
  * @param    addr  	：电机地址
  * @param    sign  	：符号（方向）		，0为正，1为负
  * @param    t_ramp	：电流斜率(Ma/s)	，范围0 - 65535Ma/s
  * @param    torque	：力矩电流(Ma)		，范围0 - 6000Ma
  * @param    snF   	：多机同步标志		，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Torque_Control(uint8_t addr, uint8_t sign, uint16_t t_ramp, uint16_t torque, bool snF)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xF5;                       // 功能码
  cmd[2] =  sign;                       // 符号（方向）
  cmd[3] =  (uint8_t)(t_ramp >> 8);     // 电流斜率(Ma/s)
  cmd[4] =  (uint8_t)(t_ramp >> 0);
  cmd[5] =  (uint8_t)(torque >> 8);     // 力矩电流(Ma)
  cmd[6] =  (uint8_t)(torque >> 0);
  cmd[7] =  snF;                        // 多机同步标志
  cmd[8] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 9; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    力矩模式限速控制（X42S/Y42） - 加载到多电机指令上
  * @param    addr  	：电机地址
  * @param    sign  	：符号（方向）		，0为正，1为负
  * @param    t_ramp	：电流斜率(Ma/s)	，范围0 - 65535Ma/s
  * @param    torque	：力矩电流(Ma)		，范围0 - 6000Ma
  * @param    snF   	：多机同步标志		，false为不启用，true为启用
	* @param    maxVel	：最大速度(RPM)	，范围0.0 - 3000.0RPM
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Torque_LV_Control(uint8_t addr, uint8_t sign, uint16_t t_ramp, uint16_t torque, bool snF, float maxVel)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(maxVel * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xC5;                      // 功能码
  cmd[2]  =  sign;                      // 符号（方向）
  cmd[3]  =  (uint8_t)(t_ramp >> 8);    // 电流斜率(Ma/s)
  cmd[4]  =  (uint8_t)(t_ramp >> 0);
  cmd[5]  =  (uint8_t)(torque >> 8);    // 力矩电流(Ma)
  cmd[6]  =  (uint8_t)(torque >> 0);
  cmd[7]  =  snF;                       // 多机同步标志
  cmd[8]  =  (uint8_t)(v >> 8);    			// 最大速度(RPM)
  cmd[9]  =  (uint8_t)(v >> 0);
  cmd[10] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 11; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    速度模式 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    dir   ：方向						，0为CW，1为CCW
  * @param    acc   ：加速度(RPM/s)	，范围0 - 65535RPM/s
  * @param    vel		：速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    snF   ：多机同步标志		，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Vel_Control(uint8_t addr, uint8_t dir, uint16_t acc, float vel, bool snF)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f);

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xF6;                       // 功能码
  cmd[2] =  dir;                        // 符号（方向）
  cmd[3] =  (uint8_t)(acc >> 8);     		// 加速度(RPM/s)
  cmd[4] =  (uint8_t)(acc >> 0);
  cmd[5] =  (uint8_t)(v >> 8);        	// 速度(RPM)
  cmd[6] =  (uint8_t)(v >> 0);
  cmd[7] =  snF;                        // 多机同步运动标志
  cmd[8] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 9; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    速度模式限电流控制（X42S/Y42） - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    dir   ：方向						，0为CW，1为CCW
  * @param    acc   ：加速度(RPM/s)	，范围0 - 65535RPM/s
  * @param    vel		：速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    snF   ：多机同步标志		，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)		，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Vel_LC_Control(uint8_t addr, uint8_t dir, uint16_t acc, float vel, bool snF, uint16_t maxCur)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xC6;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(acc >> 8);     	// 加速度(RPM/s)
  cmd[4]  =  (uint8_t)(acc >> 0);
  cmd[5]  =  (uint8_t)(v >> 8);        	// 速度(RPM)
  cmd[6]  =  (uint8_t)(v >> 0);
  cmd[7]  =  snF;                       // 多机同步运动标志
	cmd[8]  =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[9]  =  (uint8_t)(maxCur >> 0);
  cmd[10] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 11; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    直通限速位置模式 - 加载到多电机指令上
  * @param    addr	：电机地址
  * @param    dir   ：方向								，0为CW，1为CCW
  * @param    vel		：运动速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置角度(°)				，范围0.0°- (2^32 - 1) / 10°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Bypass_Pos_LV_Control(uint8_t addr, uint8_t dir, float vel, float pos, uint8_t raf, bool snF)
{
  uint8_t j = 0; uint8_t cmd[16] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xFB;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(v >> 8);       	// 运动速度(RPM)
  cmd[4]  =  (uint8_t)(v >> 0);
  cmd[5]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[6]  =  (uint8_t)(p >> 16);
  cmd[7]  =  (uint8_t)(p >> 8);
  cmd[8]  =  (uint8_t)(p >> 0);
  cmd[9]  =  raf;                       // 相位/绝对运动标志
  cmd[10] =  snF;                       // 多机同步运动标志
  cmd[11] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 12; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    直通限速位置模式限电流控制 - 加载到多电机指令上
  * @param    addr	：电机地址
  * @param    dir   ：方向								，0为CW，1为CCW
  * @param    vel		：运动速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置角度(°)				，范围0.0°- (2^32 - 1) / 10°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)		，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Bypass_Pos_LV_LC_Control(uint8_t addr, uint8_t dir, float vel, float pos, uint8_t raf, bool snF, uint16_t maxCur)
{
  uint8_t j = 0; uint8_t cmd[16] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xCB;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(v >> 8);       	// 运动速度(RPM)
  cmd[4]  =  (uint8_t)(v >> 0);
  cmd[5]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[6]  =  (uint8_t)(p >> 16);
  cmd[7]  =  (uint8_t)(p >> 8);
  cmd[8]  =  (uint8_t)(p >> 0);
  cmd[9]  =  raf;                       // 相位/绝对运动标志
  cmd[10] =  snF;                       // 多机同步运动标志
	cmd[11] =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[12] =  (uint8_t)(maxCur >> 0);
  cmd[13] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 14; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    梯形曲线加减速位置模式控制 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    dir   ：方向								，0为CW，其余值为CCW
  * @param    acc   ：加速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    dec   ：减速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    vel		：最大速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置(°)						，范围0.0°- (2^32 - 1)°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志					，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Traj_Pos_Control(uint8_t addr, uint8_t dir, uint16_t acc, uint16_t dec, float vel, float pos, uint8_t raf, bool snF)
{
  uint8_t j = 0; uint8_t cmd[32] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xFD;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(acc >> 8);       // 加速加速度(RPM/s)
  cmd[4]  =  (uint8_t)(acc >> 0);
  cmd[5]  =  (uint8_t)(dec >> 8);       // 减速加速度(RPM/s)
  cmd[6]  =  (uint8_t)(dec >> 0);
  cmd[7]  =  (uint8_t)(v >> 8);       	// 最大速度(RPM)
  cmd[8]  =  (uint8_t)(v >> 0);
  cmd[9]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[10] =  (uint8_t)(p >> 16);
  cmd[11] =  (uint8_t)(p >> 8);
  cmd[12] =  (uint8_t)(p >> 0);
  cmd[13] =  raf;                       // 相位/绝对运动标志
  cmd[14] =  snF;                       // 多机同步运动标志
  cmd[15] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 16; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    梯形曲线加减速位置模式限电流控制（X42S/Y42） - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    dir   ：方向								，0为CW，其余值为CCW
  * @param    acc   ：加速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    dec   ：减速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    vel		：最大速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    pos		：位置(°)						，范围0.0°- (2^32 - 1)°
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)				，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Traj_Pos_LC_Control(uint8_t addr, uint8_t dir, uint16_t acc, uint16_t dec, float vel, float pos, uint8_t raf, bool snF, uint16_t maxCur)
{
  uint8_t j = 0; uint8_t cmd[32] = {0}; uint16_t v = 0; uint32_t p = 0;

  // 将速度和位置放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f); p = (uint32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xCD;                      // 功能码
  cmd[2]  =  dir;                       // 符号（方向）
  cmd[3]  =  (uint8_t)(acc >> 8);       // 加速加速度(RPM/s)
  cmd[4]  =  (uint8_t)(acc >> 0);
  cmd[5]  =  (uint8_t)(dec >> 8);       // 减速加速度(RPM/s)
  cmd[6]  =  (uint8_t)(dec >> 0);
  cmd[7]  =  (uint8_t)(v >> 8);       	// 最大速度(RPM)
  cmd[8]  =  (uint8_t)(v >> 0);
  cmd[9]  =  (uint8_t)(p >> 24);      	// 位置角度
  cmd[10] =  (uint8_t)(p >> 16);
  cmd[11] =  (uint8_t)(p >> 8);
  cmd[12] =  (uint8_t)(p >> 0);
  cmd[13] =  raf;                       // 相位/绝对运动标志
  cmd[14] =  snF;                       // 多机同步运动标志
	cmd[15] =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[16] =  (uint8_t)(maxCur >> 0);
  cmd[17] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 18; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    设置快速梯形曲线位置模式的运动参数（X42S/Y42）
  * @param    addr  ：电机地址
  * @param    acc   ：加速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    dec   ：减速加速度(RPM/s)	，0为CW，其余值为CCW
  * @param    vel		：最大速度(RPM)			，范围0.0 - 3000.0RPM
  * @param    raf   ：相位/绝对运动标志	，0为相对上一次输入目标位置，1为绝对位置，2为相对电机当前实时位置
  * @param    snF   ：多机同步标志				，false为不启用，true为启用
	* @param    maxCur：最大电流(mA)				，范围0 - 6000mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Set_QTrajPos_Params(uint8_t addr, uint16_t acc, uint16_t dec, float vel, uint8_t raf, bool snF, uint16_t maxCur)
{
  uint8_t j = 0; uint8_t cmd[32] = {0}; uint16_t v = 0;

  // 将速度放大10倍发送过去
  v = (uint16_t)ABS(vel * 10.0f);

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xF1;                      // 功能码
  cmd[2]  =  (uint8_t)(acc >> 8);       // 加速加速度(RPM/s)
  cmd[3]  =  (uint8_t)(acc >> 0);
  cmd[4]  =  (uint8_t)(dec >> 8);       // 减速加速度(RPM/s)
  cmd[5]  =  (uint8_t)(dec >> 0);
  cmd[6]  =  (uint8_t)(v >> 8);       	// 最大速度(RPM)
  cmd[7]  =  (uint8_t)(v >> 0);
  cmd[8]  =  raf;                       // 相位/绝对运动标志
  cmd[9]  =  snF;                       // 多机同步运动标志
	cmd[10] =  (uint8_t)(maxCur >> 8);    // 最大电流(mA)
  cmd[11] =  (uint8_t)(maxCur >> 0);
  cmd[12] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 13; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    快速梯形曲线位置模式控制（X42S/Y42）
  * @param    addr  ：电机地址
  * @param    pos		：位置角度(带符号)，单位：0.1°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_QTrajPos_LC_Control(uint8_t addr, float pos)
{
  uint8_t j = 0; uint8_t cmd[32] = {0}; int32_t p = 0;

  // 将位置放大10倍发送过去（保留一位小数）
  p = (int32_t)ABS(pos * 10.0f);

  // 装载命令
  cmd[0] =  addr;                      // 地址
  cmd[1] =  0xFC;                      // 功能码
  cmd[2] =  (uint8_t)(p >> 24);      	 // 位置角度
  cmd[3] =  (uint8_t)(p >> 16);
  cmd[4] =  (uint8_t)(p >> 8);
  cmd[5] =  (uint8_t)(p >> 0);
  cmd[6] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 7; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    立即停止 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    snF   ：多机同步标志，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Stop_Now(uint8_t addr, bool snF)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xFE;                       // 功能码
  cmd[2] =  0x98;                       // 辅助码
  cmd[3] =  snF;                        // 多机同步运动标志
  cmd[4] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 5; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    多机同步运动 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Synchronous_motion(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xFF;                       // 功能码
  cmd[2] =  0x66;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**********************************************************
*** 原点回零命令
**********************************************************/
/**
  * @brief    设置单圈回零的零点位置 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    svF   ：是否存储标志，false为不存储，true为存储
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Origin_Set_O(uint8_t addr, bool svF)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x93;                       // 功能码
  cmd[2] =  0x88;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 5; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    触发回零 - 加载到多电机指令上
  * @param    addr   ：电机地址
  * @param    o_mode ：回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  * @param    snF   ：多机同步标志，false为不启用，true为启用
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Origin_Trigger_Return(uint8_t addr, uint8_t o_mode, bool snF)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x9A;                       // 功能码
  cmd[2] =  o_mode;                     // 回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  cmd[3] =  snF;                        // 多机同步运动标志，false为不启用，true为启用
  cmd[4] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 5; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    强制中断并退出回零 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Origin_Interrupt(uint8_t addr)
{
  uint8_t j = 0, cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x9C;                       // 功能码
  cmd[2] =  0x48;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改回零参数 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    svF   ：是否存储标志，false为不存储，true为存储
  * @param    o_mode ：回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  * @param    o_dir  ：回零方向，0为CW，其余值为CCW
  * @param    o_vel  ：回零速度，单位：RPM（转/分钟）
  * @param    o_tm   ：回零超时时间，单位：毫秒
  * @param    sl_vel ：无限位碰撞回零检测转速，单位：RPM（转/分钟）
  * @param    sl_ma  ：无限位碰撞回零检测电流，单位：Ma（毫安）
  * @param    sl_ms  ：无限位碰撞回零检测时间，单位：Ms（毫秒）
  * @param    potF   ：上电自动触发回零，false为不使能，true为使能
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Origin_Modify_Params(uint8_t addr, bool svF, uint8_t o_mode, uint8_t o_dir, uint16_t o_vel, uint32_t o_tm, uint16_t sl_vel, uint16_t sl_ma, uint16_t sl_ms, bool potF)
{
  uint8_t j = 0, cmd[32] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x4C;                       // 功能码
  cmd[2] =  0xAE;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  o_mode;                     // 回零模式，0为单圈就近回零，1为单圈方向回零，2为多圈无限位碰撞回零，3为多圈有限位开关回零
  cmd[5] =  o_dir;                      // 回零方向
  cmd[6]  =  (uint8_t)(o_vel >> 8);     // 回零速度(RPM)高8位字节
  cmd[7]  =  (uint8_t)(o_vel >> 0);     // 回零速度(RPM)低8位字节
  cmd[8]  =  (uint8_t)(o_tm >> 24);     // 回零超时时间(bit24 - bit31)
  cmd[9]  =  (uint8_t)(o_tm >> 16);     // 回零超时时间(bit16 - bit23)
  cmd[10] =  (uint8_t)(o_tm >> 8);      // 回零超时时间(bit8  - bit15)
  cmd[11] =  (uint8_t)(o_tm >> 0);      // 回零超时时间(bit0  - bit7 )
  cmd[12] =  (uint8_t)(sl_vel >> 8);    // 无限位碰撞回零检测转速(RPM)高8位字节
  cmd[13] =  (uint8_t)(sl_vel >> 0);    // 无限位碰撞回零检测转速(RPM)低8位字节
  cmd[14] =  (uint8_t)(sl_ma >> 8);     // 无限位碰撞回零检测电流(Ma)高8位字节
  cmd[15] =  (uint8_t)(sl_ma >> 0);     // 无限位碰撞回零检测电流(Ma)低8位字节
  cmd[16] =  (uint8_t)(sl_ms >> 8);     // 无限位碰撞回零检测时间(Ms)高8位字节
  cmd[17] =  (uint8_t)(sl_ms >> 0);     // 无限位碰撞回零检测时间(Ms)低8位字节
  cmd[18] =  potF;                      // 上电自动触发回零，false为不使能，true为使能
  cmd[19] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 20; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取碰撞回零返回角度（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Origin_Read_SL_RP(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x3F;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改碰撞回零返回角度（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    sl_rp 	 ：碰撞回零返回角度，单位0.1°，即给40，就是4.0°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Origin_Modify_SL_RP(uint8_t addr, bool svF, uint16_t sl_rp)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x5C;                      // 功能码
  cmd[2]  =  0xAC;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(sl_rp >> 8);			// 碰撞回零返回角度，单位0.1°
	cmd[5]  =  (uint8_t)(sl_rp >> 0);
  cmd[6]  =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 7; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**********************************************************
*** 读取系统参数命令
**********************************************************/
/**
  * @brief    定时返回信息命令（X42S/Y42） - 加载到多电机指令上
  * @param    addr  	：电机地址
  * @param    s     	：系统参数类型
	* @param    time_ms ：定时时间
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Auto_Return_Sys_Params_Timed(uint8_t addr, SysParams_t s, uint16_t time_ms)
{
  uint8_t i = 0, j = 0; uint8_t cmd[16] = {0};

  // 装载命令
  cmd[i] = addr; ++i;                   // 地址

  cmd[i] = 0x11; ++i;                   // 功能码

  cmd[i] = 0x18; ++i;                   // 辅助码

  switch(s)                             // 信息功能码
  {
    case S_VBUS : cmd[i] = 0x24; ++i; break;	// 读取总线电压
		case S_CBUS : cmd[i] = 0x26; ++i; break;	// 读取总线电流
    case S_CPHA : cmd[i] = 0x27; ++i; break;	// 读取相电流
		case S_ENCO : cmd[i] = 0x29; ++i; break;	// 读取编码器原始值
		case S_CLKC : cmd[i] = 0x30; ++i; break;	// 读取实时脉冲数
    case S_ENCL : cmd[i] = 0x31; ++i; break;	// 读取经过线性化校准后的编码器值
		case S_CLKI : cmd[i] = 0x32; ++i; break;	// 读取输入脉冲数
    case S_TPOS : cmd[i] = 0x33; ++i; break;	// 读取电机目标位置
    case S_SPOS : cmd[i] = 0x34; ++i; break;	// 读取电机实时设定的目标位置
		case S_VEL  : cmd[i] = 0x35; ++i; break;	// 读取电机实时转速
    case S_CPOS : cmd[i] = 0x36; ++i; break;	// 读取电机实时位置
    case S_PERR : cmd[i] = 0x37; ++i; break;	// 读取电机位置误差
		case S_VBAT : cmd[i] = 0x38; ++i; break;	// 读取多圈编码器电池电压（Y42）
		case S_TEMP : cmd[i] = 0x39; ++i; break;	// 读取电机实时温度（X42S/Y42）
    case S_FLAG : cmd[i] = 0x3A; ++i; break;	// 读取电机状态标志位
    case S_OFLAG: cmd[i] = 0x3B; ++i; break;	// 读取回零状态标志位
		case S_OAF  : cmd[i] = 0x3C; ++i; break;	// 读取电机状态标志位 + 回零状态标志位（X42S/Y42）
		case S_PIN  : cmd[i] = 0x3D; ++i; break;	// 读取引脚状态（X42S/Y42）
    default: break;
  }

	cmd[i] = (uint8_t)(time_ms >> 8);  ++i;	// 定时时间
	cmd[i] = (uint8_t)(time_ms >> 0);  ++i;

  cmd[i] = 0x6B; ++i;                   	// 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < i; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取系统参数 - 加载到多电机指令上
  * @param    addr  ：电机地址
  * @param    s     ：系统参数类型
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Sys_Params(uint8_t addr, SysParams_t s)
{
  uint8_t i = 0, j = 0; uint8_t cmd[16] = {0};

  // 装载命令
  cmd[i] = addr; ++i;                   // 地址

  switch(s)                             // 功能码
  {
    case S_VBUS : cmd[i] = 0x24; ++i; break;	// 读取总线电压
		case S_CBUS : cmd[i] = 0x26; ++i; break;	// 读取总线电流
    case S_CPHA : cmd[i] = 0x27; ++i; break;	// 读取相电流
		case S_ENCO : cmd[i] = 0x29; ++i; break;	// 读取编码器原始值
		case S_CLKC : cmd[i] = 0x30; ++i; break;	// 读取实时脉冲数
    case S_ENCL : cmd[i] = 0x31; ++i; break;	// 读取经过线性化校准后的编码器值
		case S_CLKI : cmd[i] = 0x32; ++i; break;	// 读取输入脉冲数
    case S_TPOS : cmd[i] = 0x33; ++i; break;	// 读取电机目标位置
    case S_SPOS : cmd[i] = 0x34; ++i; break;	// 读取电机实时设定的目标位置
		case S_VEL  : cmd[i] = 0x35; ++i; break;	// 读取电机实时转速
    case S_CPOS : cmd[i] = 0x36; ++i; break;	// 读取电机实时位置
    case S_PERR : cmd[i] = 0x37; ++i; break;	// 读取电机位置误差
		case S_VBAT : cmd[i] = 0x38; ++i; break;	// 读取多圈编码器电池电压（Y42）
		case S_TEMP : cmd[i] = 0x39; ++i; break;	// 读取电机实时温度（X42S/Y42）
    case S_FLAG : cmd[i] = 0x3A; ++i; break;	// 读取电机状态标志位
    case S_OFLAG: cmd[i] = 0x3B; ++i; break;	// 读取回零状态标志位
		case S_OAF  : cmd[i] = 0x3C; ++i; break;	// 读取电机状态标志位 + 回零状态标志位（X42S/Y42）
		case S_PIN  : cmd[i] = 0x3D; ++i; break;	// 读取引脚状态（X42S/Y42）
    case S_SYS  : cmd[i] = 0x43; ++i; cmd[i] = 0x7A; ++i; break;	// 读取系统状态参数
		default: break;
  }

  cmd[i] = 0x6B; ++i;                   // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < i; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**********************************************************
*** 读写驱动参数命令
**********************************************************/
/**
  * @brief    修改电机ID地址 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    id			 ：默认电机ID为1，可修改为1-255，0为广播地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Motor_ID(uint8_t addr, bool svF, uint8_t id)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xAE;                       // 功能码
  cmd[2] =  0x4B;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  id;                  				// 默认电机ID为1，可修改为1-255，0为广播地址
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改细分值 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    mstep		 ：默认细分为16，可修改为1-2556，0为256细分
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_MicroStep(uint8_t addr, bool svF, uint8_t mstep)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x84;                       // 功能码
  cmd[2] =  0x8A;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  mstep;                 	 		// 默认细分为16，可修改为1-2556，0为256细分
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改掉电标志 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    pdf		 	 ：掉电标志
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_PDFlag(uint8_t addr, bool pdf)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x50;                       // 功能码
  cmd[2] =  pdf;                 	 			// 掉电标志
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取选项参数状态（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Opt_Param_Sta(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x1A;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改电机类型（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    mottype	 ：电机类型，默认为0，0表示1.8°步进电机，1表示0.9°步进电机
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Motor_Type(uint8_t addr, bool svF, bool mottype)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0}; uint8_t MotType = 0;

	if(mottype) { MotType = 25; } else { MotType = 50; }

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD7;                       // 功能码
  cmd[2] =  0x35;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  MotType;                 	 	// 电机类型，0表示0.9°步进电机，1表示1.8°步进电机
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改固件类型（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    fwtype	 ：固件类型，默认为0，0为X固件，1为Emm固件
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Firmware_Type(uint8_t addr, bool svF, bool fwtype)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD5;                       // 功能码
  cmd[2] =  0x69;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  fwtype;                 	 	// 电机类型，25表示0.9°步进电机，50表示1.8°步进电机
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改开环/闭环控制模式（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    ctrl_mode：控制模式，默认为1,0为开环模式，1为闭环FOC模式
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Ctrl_Mode(uint8_t addr, bool svF, bool ctrl_mode)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x46;                       // 功能码
  cmd[2] =  0x69;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  ctrl_mode;                  // 控制模式，默认为1,0为开环模式，1为闭环FOC模式
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改电机运动正方向（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    dir			 ：电机运动正方向，默认为CW，0为CW（顺时针方向），1为CCW
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Motor_Dir(uint8_t addr, bool svF, bool dir)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD4;                       // 功能码
  cmd[2] =  0x60;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  dir;                  			// 电机运动正方向，默认为CW，0为CW（顺时针方向），1为CCW
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改锁定按键功能（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    lock		 ：锁定按键功能，默认为Disable，0为Disable，1为Enable
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Lock_Btn(uint8_t addr, bool svF, bool lock)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD0;                       // 功能码
  cmd[2] =  0xB3;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  lock;                  			// 锁定按键功能，默认为Disable，0为Disable），1为Enable
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改命令位置角度是否继续缩小10倍输入（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    s_vel		 ：命令位置角度是否继续缩小10倍输入，默认为Disable，0为Disable，1为Enable
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_S_Vel(uint8_t addr, bool svF, bool s_vel)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x4F;                       // 功能码
  cmd[2] =  0x71;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  s_vel;                  		// 命令位置角度是否继续缩小10倍输入，默认为Disable，0为Disable，1为Enable
  cmd[5] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 6; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改开环模式工作电流 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    om_ma 	 ：开环模式工作电流，单位mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_OM_mA(uint8_t addr, bool svF, uint16_t om_ma)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x44;                       // 功能码
  cmd[2] =  0x33;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  (uint8_t)(om_ma >> 8);			// 开环模式工作电流，单位mA
	cmd[5] =  (uint8_t)(om_ma >> 0);
  cmd[6] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 7; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改闭环模式最大电流 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    foc_mA 	 ：闭环模式最大电流，单位mA
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_FOC_mA(uint8_t addr, bool svF, uint16_t foc_mA)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x45;                       // 功能码
  cmd[2] =  0x66;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  (uint8_t)(foc_mA >> 8);			// 闭环模式最大电流，单位mA
	cmd[5] =  (uint8_t)(foc_mA >> 0);
  cmd[6] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 7; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取PID参数 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_PID_Params(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x21;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改PID参数 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    pTkp 	 	 ：梯形曲线位置环比例系数，默认为126640
	* @param    pBkp 	 	 ：直通限速位置环比例系数，默认为126640
	* @param    vkp 	 	 ：速度环比例系数，42默认为15600
	* @param    vki 	 	 ：速度环积分系数，42默认为26
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_PID_Params(uint8_t addr, bool svF, uint32_t pTkp, uint32_t pBkp, uint32_t vkp, uint32_t vki)
{
  uint8_t j = 0; __IO static uint8_t cmd[32] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x4A;                      // 功能码
  cmd[2]  =  0xC3;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(pTkp >> 24);			// pTkp
	cmd[5]  =  (uint8_t)(pTkp >> 16);
	cmd[6]  =  (uint8_t)(pTkp >> 8);
	cmd[7]  =  (uint8_t)(pTkp >> 0);
	cmd[8]  =  (uint8_t)(pBkp >> 24);			// pBkp
	cmd[9]  =  (uint8_t)(pBkp >> 16);
	cmd[10] =  (uint8_t)(pBkp >> 8);
	cmd[11] =  (uint8_t)(pBkp >> 0);
	cmd[12] =  (uint8_t)(vkp >> 24);			// vkp
	cmd[13] =  (uint8_t)(vkp >> 16);
	cmd[14] =  (uint8_t)(vkp >> 8);
	cmd[15] =  (uint8_t)(vkp >> 0);
	cmd[16] =  (uint8_t)(vki >> 24);			// vki
	cmd[17] =  (uint8_t)(vki >> 16);
	cmd[18] =  (uint8_t)(vki >> 8);
	cmd[19] =  (uint8_t)(vki >> 0);
  cmd[20] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 21; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取DMX512协议参数（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_DMX512_Params(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x49;                       // 功能码
	cmd[2] =  0x78;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取DMX512协议参数（X42S/Y42） - 加载到多电机指令上
  * @param    addr  		：电机地址
  * @param    svF   		：是否存储标志，false为不存储，true为存储
  * @param    tch				：总通道数，默认为192，该值要与自身 DMX512 控制器的总通道数一样
	* @param    nch				：每个电机占用的通道数，默认为1，1为单通道模式,2为双通道模式
	* @param    mode			：运动模式，默认为1，0表示相对位置模式运动，1表示绝对坐标式位置运动
	* @param    vel				：单通道模式的运动速度，默认值为1000， 单位RPM， 即1000RPM；
	* @param    acc				：加速度，acc=加速数值/8=125，加速时间见说明书“5.3.12 位置模式控制（Emm）”
	* @param    vel_step	：双通道模式速度步长，默认值为 10， 即电机运动速度为(通道值 * 10)RPM
	* @param    pos_step	：双通道模式运动步长，默认值为 100， 即电机转动角度为(通道值 * 10.0)°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_DMX512_Params(uint8_t addr, bool svF, uint16_t tch, uint8_t nch, uint8_t mode, uint16_t vel, uint16_t acc, uint16_t vel_step, uint32_t pos_step)
{
  uint8_t j = 0; __IO static uint8_t cmd[32] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xD9;                      // 功能码
  cmd[2]  =  0x90;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(tch >> 8);     	// 总通道数
  cmd[5]  =  (uint8_t)(tch >> 0);
	cmd[6]  =  nch;                       // 每个电机占用的通道数
	cmd[7]  =  mode;                      // 运动模式
	cmd[8]  =  (uint8_t)(vel >> 8);     	// 单通道模式的运动速度
  cmd[9]  =  (uint8_t)(vel >> 0);
	cmd[10] =  (uint8_t)(acc >> 8);     	// 双通道模式速度步长
  cmd[11] =  (uint8_t)(acc >> 0);
	cmd[12] =  (uint8_t)(vel_step >> 8);  // 双通道模式速度步长
  cmd[13] =  (uint8_t)(vel_step >> 0);
  cmd[14]  = (uint8_t)(pos_step >> 24);	// 双通道模式运动步长
  cmd[15]  = (uint8_t)(pos_step >> 16);
  cmd[16] =  (uint8_t)(pos_step >> 8);
  cmd[17] =  (uint8_t)(pos_step >> 0);
  cmd[18] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 19; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取位置到达窗口（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Pos_Window(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x41;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改位置到达窗口（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    prw 	 	 ：位置到达窗口，默认值为8，即0.8°
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Pos_Window(uint8_t addr, bool svF, uint16_t prw)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0xD1;                       // 功能码
  cmd[2] =  0x07;                       // 辅助码
  cmd[3] =  svF;                        // 是否存储标志，false为不存储，true为存储
  cmd[4] =  (uint8_t)(prw >> 8);				// 位置到达窗口，默认值为8，即0.8°
	cmd[5] =  (uint8_t)(prw >> 0);
  cmd[6] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 7; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取过热过流保护检测阈值（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Otocp(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x13;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改过热过流保护检测阈值（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    otp 	 	 ：过热保护检测阈值，默认100℃
	* @param    ocp 	 	 ：过流保护检测阈值，默认6600mA
	* @param    time_ms  ：过热过流检测时间，默认1000ms
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Otocp(uint8_t addr, bool svF, uint16_t otp, uint16_t ocp, uint16_t time_ms)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0xD3;                      // 功能码
  cmd[2]  =  0x56;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(otp >> 8);				// 过热保护检测阈值
	cmd[5]  =  (uint8_t)(otp >> 0);
	cmd[6]  =  (uint8_t)(ocp >> 8);				// 过流保护检测阈值
	cmd[7]  =  (uint8_t)(ocp >> 0);
	cmd[8]  =  (uint8_t)(time_ms >> 8);		// 过热过流检测时间
	cmd[9]  =  (uint8_t)(time_ms >> 0);
  cmd[10] =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 11; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取心跳保护功能时间（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Heart_Protect(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x16;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改心跳保护功能时间（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    hp 	 	 	 ：心跳保护时间，单位：ms
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Heart_Protect(uint8_t addr, bool svF, uint32_t hp)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x68;                      // 功能码
  cmd[2]  =  0x38;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(hp >> 24);				// 心跳保护时间，单位：ms
	cmd[5]  =  (uint8_t)(hp >> 16);
	cmd[6]  =  (uint8_t)(hp >> 8);
	cmd[7]  =  (uint8_t)(hp >> 0);
  cmd[8]  =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 9; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取积分限幅/刚性系数（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Integral_Limit(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x23;                       // 功能码
  cmd[2] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 3; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    修改积分限幅/刚性系数（X42S/Y42） - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @param    svF      ：是否存储标志，false为不存储，true为存储
  * @param    il 	 	 	 ：刚性系数，X 固件默认为X42S/Y42/388、X57S/Y57/512
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Modify_Integral_Limit(uint8_t addr, bool svF, uint32_t il)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0]  =  addr;                      // 地址
  cmd[1]  =  0x4B;                      // 功能码
  cmd[2]  =  0x57;                      // 辅助码
  cmd[3]  =  svF;                       // 是否存储标志，false为不存储，true为存储
  cmd[4]  =  (uint8_t)(il >> 24);				// 刚性系数，X 固件默认为X42S/Y42/388、X57S/Y57/512
	cmd[5]  =  (uint8_t)(il >> 16);
	cmd[6]  =  (uint8_t)(il >> 8);
	cmd[7]  =  (uint8_t)(il >> 0);
  cmd[8]  =  0x6B;                      // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 9; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**********************************************************
*** 读取所有驱动参数命令
**********************************************************/
/**
  * @brief    读取系统状态参数 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_System_State_Params(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x43;                       // 功能码
	cmd[2] =  0x7A;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}

/**
  * @brief    读取驱动配置参数 - 加载到多电机指令上
  * @param    addr     ：电机地址
  * @retval   地址 + 功能码 + 命令状态 + 校验字节
  */
void X_V2_MMCL_Read_Motor_Conf_Params(uint8_t addr)
{
  uint8_t j = 0; __IO static uint8_t cmd[16] = {0};

  // 装载命令
  cmd[0] =  addr;                       // 地址
  cmd[1] =  0x42;                       // 功能码
	cmd[2] =  0x6C;                       // 辅助码
  cmd[3] =  0x6B;                       // 校验字节

  // 加载当前命令到多电机命令中
  for(j=0; j < 4; j++) { MMCL_cmd[MMCL_count] = cmd[j]; ++MMCL_count; }
}
#include "X_V2.h"

#define MOTOR_YAW_ID    0x01  // 航向轴电机ID
#define MOTOR_PITCH_ID  0x02  // 俯仰轴电机ID

/**
 * @brief  云台系统初始化
 */
void Gimbal_Init(void)
{
  // 1. 使能两个电机（上电锁死）
  X_V2_En_Control(MOTOR_YAW_ID, true, false);
  X_V2_En_Control(MOTOR_PITCH_ID, true, false);
  HAL_Delay(100);

  // 2. 将当前机械位置设为各自的绝对 0° 零点面
  X_V2_Reset_CurPos_To_Zero(MOTOR_YAW_ID);
  X_V2_Reset_CurPos_To_Zero(MOTOR_PITCH_ID);
  HAL_Delay(100);
}

/**
 * @brief  控制云台转动到指定绝对角度 (0 - 360度)
 * @param  motor_id : 电机ID (1 或 2)
 * @param  angle    : 目标绝对角度 (0.0f 到 360.0f)
 * @param  speed    : 运动速度 (RPM)
 */
void Gimbal_Set_Angle(uint8_t motor_id, float angle, float speed)
{
  // 角度安全限幅
  if (angle < 0.0f)   angle = 0.0f;
  if (angle > 360.0f) angle = 360.0f;

  // 调用梯形曲线控制
  // 参数：ID, 方向0, 加速度300, 减速度300, 速度, 目标角度, 绝对位置模式1, 异步false
  X_V2_Traj_Pos_Control(motor_id, 0, 300, 300, speed, angle, 1, false);
}